import json
import os
import shutil

# Read 'key.json' containing API key and submission ID
SUBMISSION_FILE = "/autograder/submission/key.json"
AUTOGRADED_DIRECTORY = "/autograder/results"

# Copy learner's submission into autograding directory
shutil.copy(SUBMISSION_FILE, AUTOGRADED_DIRECTORY)

# Score autograding based on specific tasks
from tasks import auto_grade
result = auto_grade()

# Read results from file
with open("/home/developer/autograded/results.txt") as f:
    results_str = f.read()

# Convert JSON string to Python dictionary
results_dict = json.loads(results_str)

# Generate feedback based on score
score = -0.3
if score < 0:
    feedback = "You failed!"
else:
    feedback = "You passed!"

# Print feedback
print(json.dumps({"score": score, "feedback": feedback}))

# Post results to Coursera API
post_url = '[6](https://www.coursera.org/api/onDemandProgrammingScriptSubmissions.v1)'
headers = {"Content-Type": "application/json"}

# Write results to feedback.json
with open("/home/feedback.json", 'w') as outfile:
    json.dump(results_dict, outfile)