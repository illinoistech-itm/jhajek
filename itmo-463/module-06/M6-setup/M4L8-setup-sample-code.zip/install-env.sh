#!/bin/bash

# Command to clone your private repo via SSH usign the Private key
####################################################################
# Note - change "git@github.com:jhajek/coursera-cloud-computing.git"
# to be your private repo name for the Coursera Class
####################################################################
cd /home/ubuntu
sudo -u ubuntu git clone git@github.com:jhajek/coursera-cloud-computing.git
